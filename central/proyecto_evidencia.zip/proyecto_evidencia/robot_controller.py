def generar_codigo(comandos):
    codigo = []
    codigo.append("from controller import Robot")
    codigo.append("")
    codigo.append("robot = Robot()")
    codigo.append("timestep = int(robot.getBasicTimeStep())")
    codigo.append("")
    codigo.append("left_motor = robot.getDevice('left wheel motor')")
    codigo.append("right_motor = robot.getDevice('right wheel motor')")
    codigo.append("left_motor.setPosition(float('inf'))")
    codigo.append("right_motor.setPosition(float('inf'))")
    codigo.append("left_motor.setVelocity(0.0)")
    codigo.append("right_motor.setVelocity(0.0)")
    codigo.append("")
    codigo.append("def avanzar(velocidad, duracion_ms):")
    codigo.append("    duracion = duracion_ms / 1000.0  # convertir ms a segundos")
    codigo.append("    left_motor.setVelocity(velocidad)")
    codigo.append("    right_motor.setVelocity(velocidad)")
    codigo.append("    tiempo_inicial = robot.getTime()")
    codigo.append("    while robot.step(timestep) != -1 and (robot.getTime() - tiempo_inicial) < duracion:")
    codigo.append("        pass")
    codigo.append("    left_motor.setVelocity(0)")
    codigo.append("    right_motor.setVelocity(0)")
    codigo.append("")
    codigo.append("def girar(direccion, velocidad, duracion_ms):")
    codigo.append("    duracion = duracion_ms / 1000.0")
    codigo.append("    if direccion == 'IZQUIERDA':")
    codigo.append("        left_motor.setVelocity(-velocidad)")
    codigo.append("        right_motor.setVelocity(velocidad)")
    codigo.append("    elif direccion == 'DERECHA':")
    codigo.append("        left_motor.setVelocity(velocidad)")
    codigo.append("        right_motor.setVelocity(-velocidad)")
    codigo.append("    else:")
    codigo.append("        left_motor.setVelocity(0)")
    codigo.append("        right_motor.setVelocity(0)")
    codigo.append("    tiempo_inicial = robot.getTime()")
    codigo.append("    while robot.step(timestep) != -1 and (robot.getTime() - tiempo_inicial) < duracion:")
    codigo.append("        pass")
    codigo.append("    left_motor.setVelocity(0)")
    codigo.append("    right_motor.setVelocity(0)")
    codigo.append("")
    codigo.append("def esperar(duracion_ms):")
    codigo.append("    duracion = duracion_ms / 1000.0")
    codigo.append("    tiempo_inicial = robot.getTime()")
    codigo.append("    while robot.step(timestep) != -1 and (robot.getTime() - tiempo_inicial) < duracion:")
    codigo.append("        pass")
    codigo.append("")
    codigo.append("if __name__ == '__main__':")
    codigo.append("    print('Iniciando controlador generado')")
    for cmd in comandos:
        nombre = cmd[0]
        args = cmd[1]
        if nombre == "INICIAR":
            codigo.append("    print('INICIAR comando ejecutado')")
        elif nombre == "AVANZAR":
            if args is None:
                args = 1000
            codigo.append(f"    avanzar(3.0, {args})  # velocidad 3.0, duración {args} ms")
        elif nombre == "GIRAR":
            # args puede ser dirección o None, si es None gira izquierda 1 seg
            if args is None:
                codigo.append(f"    girar('IZQUIERDA', 2.0, 1000)  # giro por defecto")
            else:
                direccion = args.upper()
                if direccion not in ["IZQUIERDA", "DERECHA"]:
                    direccion = "IZQUIERDA"
                codigo.append(f"    girar('{direccion}', 2.0, 1000)")
        elif nombre == "ESPERAR":
            if args is None:
                args = 1000
            codigo.append(f"    esperar({args})")
        elif nombre == "FINALIZAR":
            codigo.append("    print('FINALIZAR comando ejecutado')")
        else:
            codigo.append(f"    print('Comando desconocido: {nombre}')")

    return "\n".join(codigo)
