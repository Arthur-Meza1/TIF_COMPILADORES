//

def parser(tokens):
    valid_commands = {"INICIAR", "AVANZAR", "GIRAR", "ESPERAR", "FINALIZAR"}
    instructions = []

    for cmd, args in tokens:
        if cmd not in valid_commands:
            raise ValueError(f"Comando desconocido: {cmd}")
        # Si args tiene valores, intenta convertirlos a tipo correcto
        # Por simplicidad convertimos el primer argumento a int si es posible
        if args:
            # Por ejemplo para AVANZAR 1000, args=['1000']
            try:
                arg_val = int(args[0])
                instructions.append((cmd, arg_val))
            except:
                # Si no es un número, lo dejamos como string
                instructions.append((cmd, args[0]))
        else:
            instructions.append((cmd, None))
    return instructions
