from lexer import lexer
from parser import parser
from robot_controller import generar_codigo

def main():
    with open("entrada.txt", "r") as f:
        texto = f.read()

    tokens = lexer(texto)            # Lexer convierte texto a tokens
    comandos = parser(tokens)        # Parser convierte tokens a estructura de comandos
    codigo_python = generar_codigo(comandos)  # Genera el código Python para Webots

    with open("controlador.py", "w") as f:
        f.write(codigo_python)

    print("Archivo 'controlador.py' generado exitosamente para usar en Webots.")

if __name__ == "__main__":
    main()
