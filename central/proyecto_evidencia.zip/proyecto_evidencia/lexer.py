def lexer(text):
    lines = text.strip().splitlines()
    tokens = []

    for line in lines:
        parts = line.strip().split()
        if not parts:
            continue
        cmd = parts[0].upper()
        args = parts[1:] if len(parts) > 1 else []
        tokens.append((cmd, args))
    return tokens
