from controller import Robot

robot = Robot()
timestep = int(robot.getBasicTimeStep())

left_motor = robot.getDevice('left wheel motor')
right_motor = robot.getDevice('right wheel motor')
left_motor.setPosition(float('inf'))
right_motor.setPosition(float('inf'))
left_motor.setVelocity(0.0)
right_motor.setVelocity(0.0)

def avanzar(velocidad, duracion_ms):
    duracion = duracion_ms / 1000.0  # convertir ms a segundos
    left_motor.setVelocity(velocidad)
    right_motor.setVelocity(velocidad)
    tiempo_inicial = robot.getTime()
    while robot.step(timestep) != -1 and (robot.getTime() - tiempo_inicial) < duracion:
        pass
    left_motor.setVelocity(0)
    right_motor.setVelocity(0)

def girar(direccion, velocidad, duracion_ms):
    duracion = duracion_ms / 1000.0
    if direccion == 'IZQUIERDA':
        left_motor.setVelocity(-velocidad)
        right_motor.setVelocity(velocidad)
    elif direccion == 'DERECHA':
        left_motor.setVelocity(velocidad)
        right_motor.setVelocity(-velocidad)
    else:
        left_motor.setVelocity(0)
        right_motor.setVelocity(0)
    tiempo_inicial = robot.getTime()
    while robot.step(timestep) != -1 and (robot.getTime() - tiempo_inicial) < duracion:
        pass
    left_motor.setVelocity(0)
    right_motor.setVelocity(0)

def esperar(duracion_ms):
    duracion = duracion_ms / 1000.0
    tiempo_inicial = robot.getTime()
    while robot.step(timestep) != -1 and (robot.getTime() - tiempo_inicial) < duracion:
        pass

if __name__ == '__main__':
    print('Iniciando controlador generado')
    print('INICIAR comando ejecutado')
    avanzar(3.0, 3000)  # velocidad 3.0, duración 3000 ms
    girar('IZQUIERDA', 2.0, 1000)
    esperar(1500)
    print('FINALIZAR comando ejecutado')